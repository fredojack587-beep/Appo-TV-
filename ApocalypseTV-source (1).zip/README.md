# Apocalypse TV — prototype Android natif

## Fonctionnalités du prototype
- Accueil Apocalypse TV avec Live TV, Movies et Series
- Saisie d'une URL M3U/M3U8 et lecture d'entrées HTTP trouvées
- Formulaire Xtream Codes (prototype : teste une URL de flux live)
- Lecteur basé sur AndroidX Media3 ExoPlayer

## Limites actuelles
- Ceci est un point de départ, pas une application IPTV complète.
- Les rubriques Movies/Series sont visuelles pour l'instant.
- La connexion Xtream ne récupère pas encore automatiquement les catalogues, catégories, saisons ou épisodes ; elle teste seulement le modèle d'URL de flux live.
- Les playlists qui exigent des en-têtes, redirections spécifiques, authentification particulière ou formats non pris en charge peuvent échouer.
- Utilisez uniquement des playlists et flux que vous êtes autorisé à regarder.
- Le prototype n'a pas encore été compilé ni testé sur un appareil réel.

## Construire un APK
Ouvrez le dossier dans Android Studio/AndroidIDE compatible avec Gradle, puis lancez la tâche `assembleDebug`. Le fichier attendu est :
`app/build/outputs/apk/debug/app-debug.apk`

La compilation nécessite un JDK et le SDK Android compatibles avec Android Gradle Plugin 8.7.3. Si l'outil mobile ne les prend pas en charge, utilisez un environnement Android de développement compatible ou adaptez les versions.
