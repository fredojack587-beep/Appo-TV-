package com.apocalypsetv.app

import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var playerView: PlayerView
    private var player: ExoPlayer? = null
    private val channels = mutableListOf<Pair<String, String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(13,18,34)
        window.navigationBarColor = android.graphics.Color.rgb(13,18,34)
        buildHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply { text = label; isAllCaps = false; setOnClickListener { action() } }

    private fun buildHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.rgb(13,18,34))
            setPadding(dp(18))
        }
        val scroller = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = text("APOCALYPSE TV", 27f, android.graphics.Color.WHITE, true)
        title.gravity = Gravity.CENTER
        content.addView(title, matchWrap())
        val subtitle = text("LIVE TV  •  MOVIES  •  SERIES", 13f, 0xFF9FAFCE.toInt(), true)
        subtitle.gravity = Gravity.CENTER
        subtitle.setPadding(0, dp(6), 0, dp(18))
        content.addView(subtitle, matchWrap())

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(category("LIVE TV", 0xFF17404A.toInt()), LinearLayout.LayoutParams(0, dp(100), 1f))
        row.addView(category("MOVIES", 0xFF3B2856.toInt()), LinearLayout.LayoutParams(0, dp(100), 1f))
        row.addView(category("SERIES", 0xFF56351F.toInt()), LinearLayout.LayoutParams(0, dp(100), 1f))
        content.addView(row, matchWrap())
        content.addView(button("Ajouter une playlist M3U", { prompt("Lien M3U/M3U8") { loadM3u(it) } }), matchWrap())
        content.addView(button("Connexion Xtream Codes", { xtreamDialog() }), matchWrap())
        content.addView(button("Ouvrir un flux vidéo direct", { prompt("URL du flux vidéo") { play(it) } }), matchWrap())
        content.addView(text("Mes chaînes", 20f, android.graphics.Color.WHITE, true).apply {
            setPadding(0, dp(16), 0, dp(8))
        }, matchWrap())
        content.tag = content
        root.addView(scroller, ViewGroup.LayoutParams(-1, -1))
        scroller.addView(content)
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }

    private fun category(label: String, bg: Int): View = TextView(this).apply {
        text = label; textSize = 14f; setTextColor(-1)
        gravity = Gravity.CENTER
        setTypeface(null, android.graphics.Typeface.BOLD)
        setBackgroundColor(bg)
        isFocusable = true
        contentDescription = label
    }

    private fun prompt(title: String, onOk: (String) -> Unit) {
        val input = EditText(this).apply {
            hint = "https://…"
            setTextColor(-1); setHintTextColor(0xFF9FAFCE.toInt())
            setSingleLine(true)
        }
        AlertDialog.Builder(this).setTitle(title).setView(input)
            .setPositiveButton("Continuer") { _, _ ->
                val value = input.text.toString().trim()
                if (value.isNotEmpty()) onOk(value)
            }.setNegativeButton("Annuler", null).show()
    }

    private fun xtreamDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20))
        }
        val server = EditText(this).apply { hint = "URL du serveur, ex. https://serveur.example"; setSingleLine(true) }
        val user = EditText(this).apply { hint = "Nom d'utilisateur"; setSingleLine(true) }
        val pass = EditText(this).apply { hint = "Mot de passe"; setSingleLine(true) }
        box.addView(server); box.addView(user); box.addView(pass)
        AlertDialog.Builder(this).setTitle("Xtream Codes").setView(box)
            .setPositiveButton("Connexion") { _, _ ->
                val base = server.text.toString().trim().trimEnd('/')
                val u = user.text.toString().trim()
                val p = pass.text.toString().trim()
                if (base.isNotBlank() && u.isNotBlank() && p.isNotBlank()) {
                    // Prototype: tests the Xtream live-stream URL pattern with the supplied credentials.
                    play("$base/live/$u/$p/1.ts")
                } else Toast.makeText(this, "Complète les trois champs", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Annuler", null).show()
    }

    private fun loadM3u(address: String) {
        Toast.makeText(this, "Chargement de la playlist…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val content = URL(address).readText()
                val lines = content.lines()
                var name = "Chaîne"
                val found = mutableListOf<Pair<String, String>>()
                for (line in lines) {
                    if (line.startsWith("#EXTINF", true)) {
                        name = line.substringAfter(",", "Chaîne").trim()
                    } else if (line.trim().startsWith("http", true)) {
                        found.add(name to line.trim())
                        name = "Chaîne"
                    }
                }
                runOnUiThread {
                    channels.clear(); channels.addAll(found)
                    if (found.isEmpty()) {
                        Toast.makeText(this, "Aucune chaîne trouvée. Vérifie le lien M3U.", Toast.LENGTH_LONG).show()
                    } else showChannels()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Échec du chargement : vérifie le lien et la connexion.", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun showChannels() {
        val labels = channels.map { it.first }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Chaînes disponibles")
            .setItems(labels) { _, which -> play(channels[which].second) }
            .setNegativeButton("Fermer", null).show()
    }

    private fun play(url: String) {
        try {
            val view = PlayerView(this)
            val p = ExoPlayer.Builder(this).build()
            player?.release()
            player = p
            view.player = p
            p.setMediaItem(MediaItem.fromUri(url))
            p.addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    Toast.makeText(this@MainActivity, "Lecture impossible : format, lien ou accès serveur.", Toast.LENGTH_LONG).show()
                }
            })
            p.prepare()
            p.playWhenReady = true
            AlertDialog.Builder(this).setTitle("Apocalypse TV").setView(view)
                .setPositiveButton("Fermer") { _, _ -> p.pause() }
                .setOnDismissListener { p.pause() }.show()
        } catch (e: Exception) {
            Toast.makeText(this, "Lien vidéo invalide.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
